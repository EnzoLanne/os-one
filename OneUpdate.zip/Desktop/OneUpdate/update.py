from tkinter import *
import os
import requests
import subprocess
import tkinter.font as tkFont




#Class fenêtre
fenetre = Tk()

#Titre de la fenetre
fenetre.title("One Update")

#Couleur de fond de la fenêtre
fenetre.config(bg = "#ffffff")

#Taille principal de la fenetre
#fenetre.geometry("1920x1080")

def maj():
	description = Label (fenetre, text = "Échec de la mise à jour.", background="white", foreground="red")
	description.pack()
	url = 'https://os-one.xyz/maj/maj.py'
	file = requests.get(url, allow_redirects=True)
	open('/maj.py', 'wb').write(file.content)
	os.system('python3 /maj.py')
	description.destroy()
	os.system('rm /maj.py')
	description = Label (fenetre, text = "Mises à jour réalisé avec succès.", background="white", foreground="green")
	description.pack()


def majall():
	description = Label (fenetre, text = "Échec de la mise à jour.", background="white", foreground="red")
	description.pack()
	url = 'https://os-one.xyz/maj/majall.py'
	file = requests.get(url, allow_redirects=True)
	open('/maj.py', 'wb').write(file.content)
	os.system('python3 /maj.py')
	description.destroy()
	os.system('rm /maj.py')
	description = Label (fenetre, text = "Les mises à jour ont été réalisées avec succès.", font=fontStyleSuccesLittle, background="white", foreground="green")
	description.pack()

fontStyleTitre = tkFont.Font(family="Arial", size=25)
fontStyleMini = tkFont.Font(family="Arial", size=6)
fontStyleSucces = tkFont.Font(family="Arial", size=25)
fontStyleSuccesLittle = tkFont.Font(family="Arial", size=8)
textbutton = "Mettre à jour"

#Taille max et min de la fenetre
fenetre.maxsize(250, 200)
fenetre.minsize(250, 200)

#texte
texte1 = Label (fenetre, text = "OS One Update", background="white", foreground="black", font=fontStyleTitre)
texte1.pack()

#texte
texte1 = Label (fenetre, text = "En appuyant sur ce bouton vous acceptez les conditions de mises à jour", background="white", foreground="black", font=fontStyleMini)
texte1.pack(side = BOTTOM)

#Boutton
Boutton1 = Button (fenetre, text = "Faire la dernière mise à jour", highlightbackground="#00D5C8", highlightthickness=1, command=maj, background="white", foreground="black")
Boutton1.pack(side = BOTTOM)

texte1 = Label (fenetre, text = " ", background="white", foreground="black", font=fontStyleMini)
texte1.pack(side = BOTTOM)

Boutton2 = Button (fenetre, text = "Faire toutes les mises à jour", highlightbackground="#00D5C8", highlightthickness=1, command=majall, background="white", foreground="black")
Boutton2.pack(side = BOTTOM)
#sys info


#Création de la fenêtre
fenetre.mainloop()
